// const passport = require('passport');
// const localStrategy = require('passport-local').Strategy;
// const student = require('../models/model');


// passport.use(
//     new localStrategy({
//         usernameField:"email",
//         passwordField:"password",
//     },async (email,password, done)=>{
//         try{
//         const schooluser = await student.findeOne({
//             email
//         });
//         // console.log(schooluser);
//         if(!schooluser){
//             return done(null, false, {
//                 message:"School User not found"
//             });
//             const isMatch = await schooluser.isValidPassword(password);
//             return isMatch 
//             ? done(null, schooluser)
//             : done(null, false, {message: "Incorrect User"});
//         }
//     } catch(error){
//         done(error)
//     }
// })
// )

// passport.serializeUser(function (schooluser, done){
//     done(null, schooluser.id);
// })

// passport.deserializeUser(function(id, done){
//     student.findById(id, function(err, schooluser){
//         done(err, schooluser);
//     })
// })




// // Get the Firebase authentication and Firestore objects
// var auth = firebase.auth();
// var firestore = firebase.firestore();

// // Create a new user with email and password
// auth.createUserWithEmailAndPassword(email, password)
//   .then(function(user) {
//     // Generate an OTP code
//     var otp = Math.floor(100000 + Math.random() * 900000);

//     // Store the OTP code in Firestore
//     firestore.collection('otp').add({
//       email: aadarshraj06062001@gmail.com,
//       code: otp,
//       expires: Date.now() + 600000, // OTP code expires in 10 minutes
//     });

//     // Send the OTP code to the user's email
//     var emailText = 'Your OTP code is: ' + otp;
//     sendEmail(email, 'OTP Verification', emailText);

//     // Prompt the user to enter the OTP code
//     var userOTP = prompt('Please enter the OTP code sent to your email.');

//     // Look up the OTP code in Firestore
//     var query = firestore.collection('otp').where('email', '==', email).where('code', '==', userOTP).where('expires', '>=', Date.now());
//     query.get().then(function(querySnapshot) {
//       if (querySnapshot.size > 0) {
//         // OTP code is valid
//         user.emailVerified = true;
//         user.updateProfile({
//           emailVerified: true
//         });
//       } else {
//         // OTP code is invalid or has expired
//       }
//     }).catch(function(error) {
//       // Handle errors here
//     });
//   })
//   .catch(function(error) {
//     // Handle errors here
//   });



// {/* <script type="module"> */}
//   // Import the functions you need from the SDKs you need
//   import { initializeApp } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-app.js";
//   import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.17.2/firebase-analytics.js";
//   // TODO: Add SDKs for Firebase products that you want to use
//   // https://firebase.google.com/docs/web/setup#available-libraries

//   // Your web app's Firebase configuration
//   // For Firebase JS SDK v7.20.0 and later, measurementId is optional
//   const firebaseConfig = {
//     apiKey: "AIzaSyB4LGQQB1aa9Hocq8Fcmrl0gX4HsP_Ne48",
//     authDomain: "real-project-221e8.firebaseapp.com",
//     projectId: "real-project-221e8",
//     storageBucket: "real-project-221e8.appspot.com",
//     messagingSenderId: "657574394272",
//     appId: "1:657574394272:web:bfb30f443696cf45290cc5",
//     measurementId: "G-GVNXHJK66Z"
//   };

//   // Initialize Firebase
//   const app = initializeApp(firebaseConfig);
//   const analytics = getAnalytics(app);
// {/* </script>  */}