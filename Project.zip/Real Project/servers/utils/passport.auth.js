const passport = require('passport');
const localStrategy = require('passport-local').Strategy;
const student = require('../models/model');



passport.use(
    new localStrategy({
        usernameField: "studentId",
        passwordField: "password",

    }, async (studentId, password, done) => {
        try {
            const studentuser = await student.findOne({ studentId });
            
            if (!studentuser) {
                //user does not exist
                return done(null, false, {
                    message: "StudentId not found"
                });
            }
            // user exist then needed to verify here
            const isMatch = await studentuser.isValidPassword(password);
           return isMatch
           ? done(null, studentuser)
           : done(null, false, {message: "Incorrect Password"});

        } catch (error) {
            done(error)
        }
    })
)








passport.serializeUser(function (studentuser, done){
    done(null, studentuser.id);
   

});

passport.deserializeUser(function(id, done){
    student.findById(id, function (err, studentuser){
        done (err, studentuser);


    });
});




