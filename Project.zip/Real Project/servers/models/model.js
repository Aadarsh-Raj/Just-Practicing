const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const createHttpError = require('http-errors');


const studentsSchema = new mongoose.Schema({
    session: {
        type: String,
        // required: true
    },
    registrationNumber: {
        type: String,
        // required: true,
        unique: true
    },
    admissionDate: {
        type: String,
        // required: true
    },
    studentName: {
        type: String,
        // required: true
    },
    studentQualification: {
        type: String,

    },
    dateOfBirth: {
        type: String,
        // required: true
    },
    class: {
        type: String,
        // required: true
    },
    gender: {
        type: String,
        // required: true
    },
    motherName: {
        type: String,
        // required: true
    },
    motherDesignation: {
        type: String,
        // required: true
    },
    fatherName: {
        type: String,
        // required: true
    },
    fatherDesignation: {
        type: String,
        // required: true
    },
    address: {
        type: String,
        // required: true
    },
    photo: {
        type: String,
        // require:true
    },
    phoneNumber: {
        type: Number,
        // required: true
    },
    email: {
        type: String,
        // required: true
    },
    studentId: {
        type: String,
        required: true 
        
    },
    password: {
        type: String,
        required: true
    }

})

studentsSchema.pre('save', async function (next) {
    try {
        if (this.isNew) {
            const salt = await bcrypt.genSalt(10)
            const hashedPassword = await bcrypt.hash(this.password, salt)
            this.password = hashedPassword
        }

        next();
    } catch (error) {
        next(error);
    }
})


studentsSchema.methods.isValidPassword = async function (password) {
    try {
       return await bcrypt.compare(password, this.password);
    } catch (error) {
        throw createHttpError.InternalServerError(error.message);
    }
};


// const schoolUserSchema = new mongoose.Schema({
//     schoolemail: {
//         type: String,
//         required: true,
//         // default: 'aadarshraj06062001@gmail.com'
//     },
//     password: {
//         type: String,
//         required: true,
//         // default:'Arya'
//     }
// })

// schoolUserSchema.pre('save', async function (next) {
//     try {
//         if (this.isNew) {
//             const salt = await bcrypt.genSalt(10)
//             const hashedPassword = await bcrypt.hash(this.password, salt)
//             this.password = hashedPassword
//         }

//         next();
//     } catch (error) {
//         next(error);
//     }
// })



// schoolUserSchema.methods.isValidPassword = async function (password){
//     try {
//         return await bcrypt.compare(password, this.password);
//     } catch (error) {
//         createHttpError.InternalServerError(error.message);
//     }
// };



// creating a collection in mongodb

const student = mongoose.model('student', studentsSchema);
// const schoolUser = student.discriminator('schooluser', schoolUserSchema);
// console.log(schoolUserSchema)



// const schooluser = new student({studentId: 'aadarshraj06062001@gmail.com', password: 'Arya', registrationNumber: null});
//  schooluser.save();
// module.exports = schoolUser;
module.exports = student;

