// const mongoose = require('mongoose');
// const bcrypt = require('bcrypt');
// // const { compare } = require('bcrypt');
// const createHttpError = require('http-errors');
// const schoolSchema = new mongoose.Schema({
//     email:{
//         type: String,
//         require: true
//     },
//     password: {
//         type: String,
//         require: true,
        
//     }
    
// })

// // schoolSchema.methods.isValidPassword = async function (schoolNumber){
// //     try {
// //         return await bcrypt.compare(schoolNumber, this.schoolNumber)
// //     } catch (error) {
// //         throw createHttpError.InternalServerError(error.message)
// //     }
// // }
// const schoolUser = mongoose.model('schoolUser', schoolSchema);
// module.exports = schoolUser;