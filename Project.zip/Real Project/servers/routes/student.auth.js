const { urlencoded, json } = require('body-parser');
const express = require('express');
const router = express.Router();
const passport = require('passport');
require('passport-local').Strategy;
const student = require('../models/model');
const {ensureLoggedIn, ensureLoggedOut}= require('connect-ensure-login');
router.use(express.json());
router.use(express.urlencoded({ extended: true }));







// parent/student authentication
router.get('/parentlogin', async (req, res, next) => {
    res.render('parentlogin');
});


router.post('/parentlogin', 
ensureLoggedOut({redirectTo:'/'}),
passport.authenticate('local',{
    // successRedirect: `/auth/profile`,
    successReturnToOrRedirect:'/',
    failureRedirect: '/auth/parentlogin',
    failureFlash: true,
})
);


//school authentication for log in
router.get('/login', async (req, res, next) => {
  
    res.render('login' );
});

router.post('/login',
ensureLoggedOut({redirectTo:'/'}),
passport.authenticate('local',{
    successReturnToOrRedirect:'/',
    failureRedirect:'/auth/login',
    failureFlash: true,
}))





// School authentication for registration
router.get('/signup', async (req, res, next) => {
    res.render('signup');
})


router.post('/signup',async (req, res, next) => {
    // creating new student in db
    try {
        const schoolUserId = {
            userid: "arya_76",
            userpass: "798"
        };
        const registrationNumber = req.body.registrationNumber;
        const doesExist = await student.findOne({ registrationNumber: registrationNumber });
    
        if (doesExist) {
            console.log("checked");
            res.redirect('signup');
            return;
        }
    if (req.body.password ==  req.body.confirmPassword &&  req.body.userId == schoolUserId.userid && req.body.userPass == schoolUserId.userpass) {
            const newStudent = await new student({
                session: req.body.session,
                registrationNumber: req.body.registrationNumber,
                admissionDate: req.body.date,
                studentName: req.body.studentName,
                studentQualification: req.body.studentQualification,
                dateOfBirth: req.body.dateOfBirth,
                motherName: req.body.motherName,
                motherDesignation: req.body.motherDesignation,
                fatherName: req.body.fatherName,
                fatherDesignation: req.body.fatherDesignation,
                class: req.body.class,
                email: req.body.email,
                gender: req.body.gender,
                phoneNumber: req.body.phoneNumber,
                address: req.body.address,
                // photo: req.file.filename,
                studentId:req.body.studentId,
                password: req.body.password
            }).save();
          
            res.redirect("/");
        }
        else {
            res.send("User or password is wrong")
        }
    } catch (error) {
        res.send(error)
    }
})




router.get('/logout', async (req, res, next)=>{
    req.logout(function(err){
        if(err){return next(err)}

        res.redirect('/');
    });

   
});




module.exports = router;


// function ensureAuthenticated(req, res, next){
//     if (req.isAuthenticated()){
//         next();
//     } else {
//         res.redirect('/auth/login');
//     }
// }

// function ensureNotAuthenticated(req, res, next){
//     if(req.isAuthenticated()){
//         res.redirect('back')
//     } else {
//         next();
//     }
// }

