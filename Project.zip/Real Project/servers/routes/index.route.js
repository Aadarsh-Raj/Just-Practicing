const express = require('express');
const {ensureLoggedIn, ensureLoggedOut} = require('connect-ensure-login');
const { urlencoded, json } = require('body-parser');
const {mongodb} = require('mongodb');
const passport = require('passport');
const mongoose = require('mongoose');
const student = require('../models/model');

// const { db } = require('../models/model');
// const MongoClient = require('mongodb').MongoClient;
// const url = "mongodb://127.0.0.1:27017/";

const router = express.Router();
router.use(express.json());
router.use(express.urlencoded({ extended: false }));


router.get('/', (req, res, next) => {
    res.render('index');
    
});

router.get('/user/profile',ensureLoggedIn({redirectTo: '/'}), (req, res, next)=>{
   res.render('profile',{studentName: res.locals.studentuser.studentName,
    session: res.locals.studentuser.session,
    registrationNumber: res.locals.studentuser.registrationNumber,
    gender: res.locals.studentuser.gender,
    class: res.locals.studentuser.class,
    phoneNumber: res.locals.studentuser.phoneNumber
});
})



module.exports = router;
