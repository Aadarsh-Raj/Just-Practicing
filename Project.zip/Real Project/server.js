const express = require("express");
const createHttpError = require('http-errors');
const morgan = require('morgan');
const hbs = require('hbs');
const path = require('path');
const multer = require('multer');
const session = require('express-session');
const connectFlash = require('connect-flash');
const prompt = require('prompt-sync')();
const {ensureLoggedIn} = require('connect-ensure-login')
const passport = require('passport');

// const { json } = require('express');

const dotenv = require('dotenv');
dotenv.config({ path: '.config.env' })
const port = process.env.PORT || 3000


const app = express();

app.use(morgan('dev')); // it will console the requested url

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const connectdb = require('./servers/db/conn.js');
const { default: mongoose } = require("mongoose");
const student = require('./servers/models/model');
const { initialize } = require('passport');
mongoose.set('strictQuery', true);

// mongodb
connectdb();





// const { route } = require("./servers/routes/index.route");





// joining paths 
// const static_path = path.join(__dirname, "./assets/");
const view_path = path.join(__dirname, "./tempelates/views")
const partial_path = path.join(__dirname, "./tempelates/partials");


// serving static files
// app.use(express.static(static_path));

app.use('/css', express.static(path.join(__dirname, "./assets/css")))
app.use('/auth/css', express.static(path.join(__dirname, "./assets/css")))

app.use('/js', express.static(path.join(__dirname, "./assets/js")))
app.use('/auth/js', express.static(path.join(__dirname, "./assets/js")))



// setting up view engine
app.set("view engine", "hbs");
app.set('views', view_path);
hbs.registerPartials(partial_path)






// Init Session
app.use(
    session({
        secret:"some super secret",
        resave: false,
        saveUninitialized: false,
        cookie: {
        // secure: true,  // should be used while using secure https connection
        httpOnly: true
    }

})
);

// for passport js authentication
app.use(passport.initialize());
app.use(passport.session());
require('./servers/utils/passport.auth');




app.use((req, res, next)=>{
    res.locals.studentuser = req.user;
    // console.log(req.user)
    // console.log(res.locals)
    // console.log(req.body.studentId)
    // console.log(res.locals.studentuser)
    next();
})

// app.use((req, res, next)=>{
//     res.locals.schooluser = req.user;
//     // console.log(req.user);
//     // console.log(res.locals)
//     // console.log(res.locals.schooluser);
//     next();
// })


// connect flash
app.use(connectFlash());


// Using Router
app.use('/', require('./servers/routes/index.route'));
app.use('/auth', require('./servers/routes/student.auth'));
// app.use('/user', 
// ensureLoggedIn({redirectTo: '/user/profile'}),
// require('./servers/routes/user.route')
// );


// // uploading image
// const Storage = multer.diskStorage({
//     destination: "./assets/uploads",
//     filename: (req, photo, cb) => {
//         cb(null, photo.fieldname + "_" + Date.now() + path.extname(photo.originalname))
//     }
// })

// // Middleware
// const upload = multer({
//     storage: Storage
// }).single('photo');






// Error Handling
app.use((req, res, next) => {
    next(createHttpError.NotFound());
});


// actual error
app.use((error, req, res, next) => {
    error.status = error.status || 500;
    res.status(error.status);
    //  console.log(error);
    res.render('error_40', { error });
});





// Firebase initialization
// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyDR5y26qVr8fFf5Kw9K4lhGopjd6wwrbIw",
//   authDomain: "this-is-last-practice.firebaseapp.com",
//   projectId: "this-is-last-practice",
//   storageBucket: "this-is-last-practice.appspot.com",
//   messagingSenderId: "155199467812",
//   appId: "1:155199467812:web:b8455ee4efd701f7d443b1",
//   measurementId: "G-MW86FVJ863"
// };





app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`)
})

